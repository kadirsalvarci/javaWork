function validateForm() {
  var isim = document.forms['form1'][0].value;
  var soyIsim = document.forms['form1'][1].value;
  if (isim == null || isim == "") {
    alert("İsim kısmı boş bırakılamaz");
    return false;
  }

  if (soyIsim == null || soyIsim == "") {
    alert("Soyisim kısmı boş bırakılamaz");
    return false;
  }
}