A Pen created at CodePen.io. You can find this one at http://codepen.io/pinusart/pen/LGvwJM.

 Web uygulamalarında veri doğrulamak (validation) olmazsa olmazlardandır. Gönderilen verilerin yanlış olmaması veya istenen verilen muhakkak girilmesi gereken durumlarda bu tip uygulamalara ihtiyaç duyarsınız.

Veri doğrulama işlemi, düzgün veri girişinden ziyade kötü amaçlı kullanımları da engellemek için mecburidir.

Özellikle veritabanına giriş yapılacaksa, form doğrulamalarının (Form Validation) mutlaka "sunucu taraflı (Serverside)" scriptlerle(PHP, ASP vb.) de yapılması gerekir.